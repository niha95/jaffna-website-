<?php

if(!defined('IMAGE_PATH')) {
    define('IMAGE_PATH', __DIR__ . '/../../uploads/images/');
}

if(!defined('THUMB_PATH')) {
    define('THUMB_PATH', __DIR__ . '/../../uploads/thumbs/');
}

if(!defined('ZIP_PATH')) {
    define('ZIP_PATH', __DIR__ . '/../../uploads/ZIP/');
}

if(!defined('CV_PATH')) {
    define('CV_PATH', __DIR__ . '/../../uploads/cv/');
}