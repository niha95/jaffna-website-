<?php
namespace App\Blackburn\Pages\Modules;

class TextContentModule extends AbstractModule{

    public function renderView($locale)
    {
        $data = $this->getLocalizedData();

        return view($this->getRenderingViewFile(), [
            'm_title' => $data->title,
            'm_content' => $data->content,
            'page' => $this->page
        ])->render();
    }

    public function sanitizeData()
    {
        if(!$this->editing) return [];

        $clean = [];

        foreach($this->data['localized'] as $i) {
            $clean['m__title_' . $i['locale']] = $i['title'];
            $clean['m__content_' . $i['locale']] = $i['content'];
        }

        return $clean;
    }
}