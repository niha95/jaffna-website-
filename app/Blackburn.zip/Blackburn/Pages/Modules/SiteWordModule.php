<?php
namespace App\Blackburn\Pages\Modules;

use App\Models\NewsItem;

class SiteWordModule extends AbstractModule {

    public function renderView($locale)
    {
        return view($this->getRenderingViewFile(), [
            'page' => $this->page
        ])->render();
    }

    public function sanitizeData()
    {
        return [];
    }

    public function addTranslations()
    {
        $this->translations['site_word_translated'] = labelTranslated('pages.modules.site_word');
    }
}