<?php
namespace App\Blackburn\Layouts;

interface Renderable {

    public function render();

}