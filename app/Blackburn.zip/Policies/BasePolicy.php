<?php

namespace App\Policies;


class BasePolicy {

}
