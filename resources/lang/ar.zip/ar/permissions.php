<?php

return [
    'roles' => [
        'super_user' => 'Super User',
        'admin' => 'Admin',
        'editor' => 'Editor',
    ],
];