<?php

return [
    'created_entity' => 'User ":user" has created ":entity".',
    'edited_entity' => 'User ":user" has edited ":entity".',
    'deleted_entity' => 'User ":user" has deleted ":entity".',
];