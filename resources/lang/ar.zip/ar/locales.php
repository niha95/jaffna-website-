<?php

return [
    'ar' => 'عربى',
    'en' => 'انجليزى',
    'tr' => 'تركى',

    'ar_semi' => 'AR',
    'en_semi' => 'EN',
    'tr_semi' => 'TR',
];